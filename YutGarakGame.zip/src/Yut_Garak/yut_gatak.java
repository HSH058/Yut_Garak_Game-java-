package Yut_Garak;

import java.util.Random;

public class yut_gatak {
	private int facevalue_1;
	private int facevalue_2;
	
	void yut_garak(int facevalue_1, int facevalue_2){
		// 생성자에서 초기화
        this.facevalue_1 = facevalue_1; // 초기값 설정
        this.facevalue_2 = facevalue_2; // 초기값 설정
	}
	
	public void roll_1() {
		// Random 객체 생성
        Random random_1 = new Random();

        // 변수에 랜덤으로 0 또는 1을 할당
        facevalue_1 = random_1.nextInt(2);  // 0 또는 1 중 하나를 선택
	}
	
	public void roll_2() {
		// Random 객체 생성
        Random random_2 = new Random();

        // 변수에 랜덤으로 0 또는 1을 할당
        facevalue_2 = random_2.nextInt(2);  // 0 또는 1 중 하나를 선택
	}
	
	//1번 플레이어
	public int getFaceValue_1() {
		//윷가락을 반환
		return facevalue_1;
	}
	//2번 플레이어
	public int getFaceValue_2() {
		//윷가락을 반환
		return facevalue_2;
	}
}
