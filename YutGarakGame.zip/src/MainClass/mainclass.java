package MainClass;

import Yut_Garak_Game.yut_garak_game;

public class mainclass { 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		yut_garak_game ygg = new yut_garak_game();
		ygg.play();
	}

}
