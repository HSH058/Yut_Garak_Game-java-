package Yut_Garak_Game;

import java.util.ArrayList;
import java.util.Scanner;

import Yut_Garak.yut_gatak;

public class yut_garak_game {
	// 1번 플레이어의 정수형 변수를 담을 ArrayList 생성
    static ArrayList<Integer> integerList_1 = new ArrayList<>();
	
    // 2번 플레이어의 정수형 변수를 담을 ArrayList 생성
    static ArrayList<Integer> integerList_2 = new ArrayList<>();
    
    // 1번 플레이어
    yut_gatak yut_1 = new yut_gatak();
    
    // 2번 플레이어
    yut_gatak yut_2 = new yut_gatak();
    
    // 0번째부터 4번째 인덱스까지 값을 하나의 문자열로 합치기
    StringBuilder sb_1 = new StringBuilder();
    
    // 0번째부터 4번째 인덱스까지 값을 하나의 문자열로 합치기
    StringBuilder sb_2 = new StringBuilder();
    
    // 1번 플레이어 모양 저장 변수
    int shape_1;

    // 2번 플레이어 모양 저장 변수
    int shape_2;
    
    public yut_garak_game(){}
    
    // 게임 시작
    public void play() {
    	while(true) {
        	for(int i = 0; i < 4; i++) {
    			yut_1.roll_1();
    			int facevalue_1 = yut_1.getFaceValue_1();
    			integerList_1.add(facevalue_1);
    		}
    		
    		// 1번 플레이어의 전체 윷가락 체크
            for (int i = 0; i < 4; i++) {
                sb_1.append(integerList_1.get(i));
            }
            
            for(int i = 0; i < 4; i++) {
    			yut_2.roll_2();
    			int facevalue_2 = yut_2.getFaceValue_2();
    			integerList_2.add(facevalue_2);
    		}
            // 2번 플레이어의 전체 윷가락 체크
            for (int i = 0; i < 4; i++) {
                sb_2.append(integerList_2.get(i));
            }
       
            System.out.println("--------------------------------------");
            System.out.print("1_player : ");
            System.out.println(sb_1);
            System.out.print("모양 : ");
            if(sb_1.toString().equals("0000")) {
            	shape_1 = 4;
            	System.out.println("윷입니다.");
            }
            else if(sb_1.toString().equals("1000") || sb_1.toString().equals("0100") || sb_1.toString().equals("0010") || sb_1.toString().equals("0001")) {
            	shape_1 = 1;
            	System.out.println("도입니다.");
            }
            else if(sb_1.toString().equals("1100") || sb_1.toString().equals("1010") || sb_1.toString().equals("1001") || sb_1.toString().equals("0110") || sb_1.toString().equals("0101") || sb_1.toString().equals("0011")) {
            	shape_1 = 2;
            	System.out.println("개입니다.");
            }
            else if(sb_1.toString().equals("1110") || sb_1.toString().equals("1101") || sb_1.toString().equals("0111") || sb_1.toString().equals("1011")) {
            	shape_1 = 3;
            	System.out.println("걸입니다.");
            }
            else {
            	shape_1 = 5;
            	System.out.println("모입니다.");
            }
            
            System.out.print("2_player : ");
            System.out.println(sb_2);
            System.out.print("모양 : ");
            if(sb_2.toString().equals("0000")) {
            	shape_2 = 4;
            	System.out.println("윷입니다.");
            }
            else if(sb_2.toString().equals("1000") || sb_2.toString().equals("0100") || sb_2.toString().equals("0010") || sb_2.toString().equals("0001")) {
            	shape_2 = 1;
            	System.out.println("도입니다.");
            }
            else if(sb_2.toString().equals("1100") || sb_2.toString().equals("1010") || sb_2.toString().equals("1001") || sb_2.toString().equals("0110") || sb_2.toString().equals("0101") || sb_2.toString().equals("0011")) {
            	shape_2 = 2;
            	System.out.println("개입니다.");
            }
            else if(sb_2.toString().equals("1110") || sb_2.toString().equals("1101") || sb_2.toString().equals("0111") || sb_2.toString().equals("1011")) {
            	shape_2 = 3;
            	System.out.println("걸입니다.");
            }
            else {
            	shape_2 = 5;
            	System.out.println("모입니다.");
            }
            
            // 랜덤으로 생성된 결과를 모양으로 변경한 후 승 패를 결졍한다.
            System.out.println("--------------------------------------");
    		System.out.print("승/패 결과 : ");
            if(shape_1 == shape_2) {
    			System.out.println("무승부!");
    			System.out.println("다시 게임을 진행하겠습니까?");
    			System.out.println("1.네 2.아니오");
    			Scanner scanner = new Scanner(System.in);
    			String number = scanner.next();
    			if(number.equals("1")) {
    				// 게임 상태 초기화
    		        integerList_1.clear();
    		        integerList_2.clear();
    		        sb_1.setLength(0);
    		        sb_2.setLength(0);
    		        shape_1 = 0;
    		        shape_2 = 0;
    			}
    			else {
    				break;
    			}
    		}
    		else if(shape_1 > shape_2) {
    			System.out.println("1번 플레이어 승리!");
    			break;
    		}
    		else {
    			System.out.println("2번 플레이어 승리!");
    			break;
    		}	
            System.out.println("--------------------------------------");
        }
    }
}
